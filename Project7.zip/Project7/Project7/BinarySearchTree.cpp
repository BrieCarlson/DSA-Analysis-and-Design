//============================================================================
// Author      : Briana Carlson
// Source Code : BinarySearchTree 5-2 Assignment
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <time.h>
#include <fstream>
#include <vector>

#include "CSVparser.hpp"

using namespace std;

// forward declarations
double strToDouble(string str, char ch);

// structure to hold course information
struct Course {
    string courseName; 
    string courseNumber;
    string preReq1;
    string preReq2;
};

// Internal structure for tree node
struct Node {
    Course course;

    Node* right;
    Node* left;

    Node() {
        right = nullptr;
        left = nullptr;
    }
    Node(Course acourse) : Node() {
        this->course = acourse;
    }
};
vector<Node> nodes;


class BinarySearchTree {

private:
    Node* root;
    void addNode(Node* node, Course acourse);
    void inOrder(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Course acourse);
    Course Search(string courseNumber);
};

// Default constructor
BinarySearchTree::BinarySearchTree() {
    root = nullptr; //root is equal to nullptr
}

// Destructor
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
}

// Traverse the tree in order
void BinarySearchTree::InOrder() {
    this->inOrder(root); // call inOrder fuction and pass root 
}

// Insert a course
void BinarySearchTree::Insert(Course acourse) {
    if (root == nullptr) { // if root equarl to null ptr
        root = new Node(acourse); // root is equal to new node course
    }
    // else add Node root and course
    else {
        this->addNode(root, acourse);
    }
}


// Search for a course
Course BinarySearchTree::Search(string courseNumber) {
    Node* current = root; // current node set equal to root

    // loop downwards until bottom reached or matching courseNumber found
    while (current != nullptr) {
        // if match found, return current course
        if (current->course.courseNumber.compare(courseNumber) == 0) {
            return current->course;
        }
        // if course is smaller than current node then traverse left
        if (courseNumber.compare(current->course.courseNumber) < 0) {
            current = current->left;
        }
        else { // else traverse right
            current = current->right;
        }
    }
    Course acourse;
    return acourse;
}

// Add a course to some node (recursive)
void BinarySearchTree::addNode(Node* node, Course acourse) {

    if (node->course.courseNumber.compare(acourse.courseNumber) > 0) { // if node is larger than course, then add to left
        if (node->left == nullptr) { // if no left node
            node->left = new Node(acourse); // this node becomes left
        }
        else {
            this->addNode(node->left, acourse); // else recurse down the left node
        }
    }
    else {
        if (node->right == nullptr) { // if no right node
            node->right = new Node(acourse); // this node becomes right
        }
        else {
            this->addNode(node->right, acourse); // else recurse down the left node
        }
    }
}


void BinarySearchTree::inOrder(Node* node) {
    if (node != nullptr) { //if node is not equal to null ptr
        inOrder(node->left); //InOrder not left
        cout << node->course.courseNumber << ": " << node->course.courseName <<
            " , " << node->course.preReq1 << " , " << node->course.preReq2 << endl;
        inOrder(node->right); //InOder right
    }
}


void displayCourse(Course acourse) {
    cout << acourse.courseNumber << ": " << acourse.courseName << " , " << acourse.preReq1
        << " , " << acourse.preReq2 << endl;
    return;
}

// Load a file containing courses into a container
void loadFile(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    // read and display header row
    vector<string> header = file.getHeader();
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;


    // loop to read rows of a CSV file
    for (unsigned int i = 0; i < file.rowCount(); i++) {

        // Create a data structure and add to the collection of courses
        Course acourse;
        acourse.courseNumber = file[i][0];
        acourse.courseName = file[i][1];
        acourse.preReq1 = file[i][2];
        acourse.preReq1 = file[i][3];
        cout << acourse.courseNumber << ": " << acourse.courseName << " , " << acourse.preReq1
            << " , " << acourse.preReq2 << endl;

        
        bst->Insert(acourse); // push this course to the end
    }

}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}


int main(int argc, char* argv[]) {

    string csvPath, courseKey;
    //string fileInput;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        courseKey = "MATH201";
        break;
    case 3:
        csvPath = argv[1];
        courseKey = argv[2];
        break;
    default:
        csvPath = "CourseData.csv";
        //csvPath = fileInput;
        courseKey = "MATH201";
    }

    // Define a binary search tree to hold all courses
    BinarySearchTree* bst;
    bst = nullptr;

    Course acourse;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Data Structure" << endl;
        cout << "  2. Print Course List" << endl;
        cout << "  3. Search Course" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            bst = new BinarySearchTree();
            //cout << "Enter file name: " << endl;
            //cin >> fileInput;
            loadFile(csvPath, bst);
            break;

        case 2:
            bst->InOrder();
            break;

        case 3:
            cout << "Enter a course to search: " << endl;
            cin >> courseKey;
            acourse = bst->Search(courseKey);

            if (!acourse.courseNumber.empty()) {
                displayCourse(acourse);
            }
            else {
                cout << "Course Number " << courseKey << " not found." << endl;
            }

            break;
        }

    }

    cout << "Good bye." << endl;

    return 0;
}
